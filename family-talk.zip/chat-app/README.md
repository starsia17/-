# Family Talk - 실시간 채팅 사이트

Node.js + Express + Socket.io + MongoDB(Mongoose) 기반 실시간 채팅 웹앱입니다.

## 주요 기능
- IP 기반 프로필(닉네임/사진) 고정 저장, IP당 1개 프로필만 생성 가능
- 채팅방 생성(제목 + 선택적 비밀번호), 목록 페이지네이션(페이지당 10개)
- 실시간 텍스트/이미지/동영상 채팅 (Socket.io)
- 입장 시 이전 채팅 내역 로딩
- + 버튼으로 투표 생성 및 실시간 투표 결과 반영
- 참여자 목록 사이드 패널
- 방장 전용 공지사항 작성 / 참여자 강퇴(IP 기반 재입장 차단)
- 모바일 터치 환경 최적화 반응형 UI

## 폴더 구조
```
chat-app/
├─ server.js              # Express + Socket.io 서버
├─ models/                # Mongoose 스키마 (User, Room, Message)
├─ public/                # 프론트엔드 (index.html, room.html, css, js)
└─ uploads/                # 업로드된 이미지/동영상 저장 (Render 무료 플랜은 재배포 시 초기화됨)
```

## 로컬 실행 방법
1. `npm install`
2. `.env.example`을 `.env`로 복사 후 `MONGODB_URI`에 본인의 MongoDB Atlas 연결 문자열 입력
3. `npm start`
4. 브라우저에서 `http://localhost:3000` 접속

## Render 배포 방법 (이미 준비된 환경 기준)
1. 이 코드를 GitHub 저장소(starsia17)에 push
2. Render 대시보드 → Web Service(Family Talk) → **Manual Deploy**로 최신 커밋 배포
   - Build Command: `npm install`
   - Start Command: `npm start`
3. Environment Variables에 `MONGODB_URI` 값이 MongoDB Atlas의 Cluster0 연결 문자열로 설정되어 있는지 확인
   - Atlas > Connect > Drivers 에서 연결 문자열 복사 후 비밀번호 부분을 실제 DB 계정 비밀번호로 교체
4. 배포 완료 후 `https://family-talk-ivnx.onrender.com` 접속하여 확인

## 주의사항 (무료 플랜 한계)
- Render 무료 플랜은 파일 시스템이 영구 저장되지 않아, 재배포/재시작 시 `uploads` 폴더의 이미지/동영상이 사라질 수 있습니다.
  실서비스로 계속 운영할 경우 Cloudinary, AWS S3 같은 외부 스토리지 연동을 권장합니다.
- 참여자 목록(`roomMembers`)은 서버 메모리에 저장되므로, 서버가 재시작되면 초기화됩니다(채팅 기록/방/프로필은 MongoDB에 저장되어 유지됩니다).
- IP 기반 식별은 같은 공유 와이파이(NAT) 환경에서 여러 사용자가 같은 IP로 인식될 수 있는 한계가 있습니다.
